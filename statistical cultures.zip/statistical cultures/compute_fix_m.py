import mapel
import time
import os
import csv
import sys

if __name__ == "__main__":

    target = str(sys.argv[1])
    SIZE = int(sys.argv[2])

    num_candidates = 10
    num_threads = 1

    values = []

    my_dict = {'ic': ['impartial_culture', {}],
               'half': ['norm_mallows', {'norm-phi': 0.5}],
               'wal': ['walsh', {}],
               'con': ['conitzer', {}],
               'int': ['1d_interval', {}],
               'id':  ['real_identity', {}]}

    x_values = [5,10,15,20,25,30,35,40,45,50]

    for num_voters in x_values:

        total_time = 0
        for i in range(SIZE):
            experiment = mapel.prepare_experiment()
            experiment.set_default_num_candidates(num_candidates)
            experiment.set_default_num_voters(num_voters)
            experiment.add_family(election_model=my_dict[target][0], size=2,
                                  params=my_dict[target][1])
            start = time.time()
            experiment.compute_distances(distance_name='0-voter_subelection',
                                         num_threads=num_threads)
            stop = time.time()
            total_time += stop - start
        values.append(total_time/float(SIZE))

        name = target + '_m'
        path = os.path.join(os.getcwd(), 'fix_m', name)

        with open(path, 'w', newline='') as csv_file:
            writer = csv.writer(csv_file, delimiter=',')
            writer.writerow(["id", "value"])
            for i, v in enumerate(values):
                writer.writerow([i, v])







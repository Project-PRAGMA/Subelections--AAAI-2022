import mapel
import sys

if __name__ == "__main__":

    num_candidates = int(sys.argv[1])
    experiment_id = 'sub_' + str(num_candidates)

    experiment = mapel.prepare_experiment(experiment_id=experiment_id)

    experiment.set_default_num_candidates(num_candidates)
    experiment.set_default_num_voters(50)
    
    experiment.prepare_elections()

    mapel.compute_subelection_by_groups(experiment=experiment, precision=1000,
                                        num_threads=100, self_distances=True)


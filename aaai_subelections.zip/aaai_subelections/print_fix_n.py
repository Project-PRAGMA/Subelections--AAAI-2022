import matplotlib.pyplot as plt
import os
import csv

if __name__ == "__main__":


    my_dict = {'ic': ['impartial_culture', {}],
               'half': ['norm_mallows', {'norm-phi': 0.5}],
               'wal': ['walsh', {}],
               'con': ['conitzer', {}],
               'int': ['1d_interval', {}],
               'id':  ['real_identity', {}]}

    x_values = [3,4,5,6,7,8,9,10]

    for name in my_dict:

        file_name = name + '_n'
        path = os.path.join(os.getcwd(), 'fix_n', file_name)

        with open(path, 'r', newline='') as csv_file:
            reader = csv.DictReader(csv_file, delimiter=',')
            my_dict[name] = []
            for i, row in enumerate(reader):
                value = float(row['value'])
                my_dict[name].append(value)

    LABELS = {'ic': 'IC',
               'half': 'Mallows 0.5',
               'wal': 'SP by Walsh',
               'con': 'SP by Conitzer',
               'int': '1D-Interval',
               'id':  'ID'}

    plt.xlabel('number of candidates', size=18)
    plt.ylabel('average time in seconds', size=18)
    for name in my_dict:
        print(my_dict[name])
        plt.plot(x_values, my_dict[name], label=LABELS[name])
    plt.legend(prop={'size': 15})
    plt.tick_params(labelsize=14)
    plt.savefig('fix_n', bbox_inches='tight')
    plt.show()









